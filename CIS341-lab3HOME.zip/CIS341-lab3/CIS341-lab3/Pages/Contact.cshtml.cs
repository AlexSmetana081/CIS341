using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Diagnostics;

namespace CIS341_lab3.Pages
{
    public class ContactModel : PageModel
    {

        public string? Namemessage { get; set; }
        public string? Emailmessage { get; set; }
        public string? Message { get; set; }

        public const string? Placeholder = "Enter your message here.";

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            // Output to the debug console.
            // The public properties in the class are automatically bound from the form data.
            // Does not check whether the submitted data is valid; that's a story for another day.
            Debug.WriteLine($"Message is: {Message}");
            return new EmptyResult();
        }

    }
}
