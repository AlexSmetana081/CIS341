using CIS341_lab3.Entity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Diagnostics;

namespace CIS341_lab3.Pages
{
    // Bind all public properties of the page model to request data for POST requests.
    [BindProperties]
    public class ContactModel : PageModel
    {

        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? Message { get; set; }

        public const string? NamePlaceholder = "Enter your Name here.";

        public const string? EmailPlaceholder = "Enter your Email here.";

        public const string? MessagePlaceholder = "Enter your Message here.";

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {

                Contact contact = new Contact();

                contact.Name = Name;
                contact.Email = Email;
                contact.Message = Message;

                // Process the submitted data (e.g., save to a database).
                // For debugging purposes, print the data to the console.
                Console.WriteLine($"Name: {contact.Name}");
                Console.WriteLine($"Email: {contact.Email}");
                Console.WriteLine($"Message: {contact.Message}");

                // Redirect back to the Index page or any other page as needed.
                return RedirectToPage("Index");
            }

            // If ModelState is not valid, stay on the current page to show errors.
            return Page();
        }
        

    }
}
