﻿namespace Lab05.Models
{
    public class TrackedWorkoutModel
    {
        public int TrackedWorkoutID { get; set; }

        public int WorkoutID { get; set; }
        public WorkoutModel Workout { get; set; } = new WorkoutModel();
        
        public DateTime DateCompleted { get; set; }

        public int AccountID { get; set; }
        public AccountModel Account { get; set; } = new AccountModel();
    }
}
