﻿using Lab05.Models;

namespace Lab05.ViewModels
{
    public class AccountDTO
    {
        public int AccountId { get; set; }
        public string Name { get; set; } = string.Empty;

        public string Email { get; set; } = string.Empty;

        public string Password { get; set; } = string.Empty;

        //Account to role
        public int RoleId { get; set; }
        public RoleModel Role { get; set; } = new RoleModel();

        public List<TrackedWorkoutModel> TrackedWorkouts { get; set; } = new List<TrackedWorkoutModel>();

    }
}
