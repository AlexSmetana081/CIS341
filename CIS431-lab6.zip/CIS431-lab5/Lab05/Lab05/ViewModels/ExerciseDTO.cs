﻿using Lab05.Models;

namespace Lab05.ViewModels
{
    public class ExerciseDTO
    {
        public int ExerciseId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;


        //Author Id and Author 
        public int AuthorId { get; set; }
        public AccountModel Author { get; set; } = new AccountModel();
        public int Length { get; set; }
        public int Intensity { get; set; }
    }
}
