﻿namespace Lab05.ViewModels
{
    public class RoleDTO
    {
        public int RoleId { get; set; }
        public string Name { get; set; } = string.Empty;
    }
}
