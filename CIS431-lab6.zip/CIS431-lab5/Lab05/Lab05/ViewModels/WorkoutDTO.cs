﻿using Lab05.Models;

namespace Lab05.ViewModels
{
    public class WorkoutDTO
    {
        public int WorkoutId { get; set; }
        public string Name { get; set; } = string.Empty;

        //Author to Workout
        public int AuthorId { get; set; }
        public AccountModel Author { get; set; } = new AccountModel();
        public List<ExerciseModel> Exercises { get; set; } = new List<ExerciseModel>();
    }
}
