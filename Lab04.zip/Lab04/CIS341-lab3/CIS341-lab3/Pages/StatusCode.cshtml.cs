using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System.Net;

namespace CIS341_lab3.Pages
{
    public class StatusCodeModel : PageModel
    {

        private readonly ILogger<StatusCodeModel> _logger;
        public string? ErrorMessage { get; set; }

        public StatusCodeModel(ILogger<StatusCodeModel> logger)
        {
            _logger = logger;
        }

        // Delegate that defines the log message template.
        private static readonly Action<ILogger, string, DateTime, string, Exception?> _loggerMessage =
            LoggerMessage.Define<string, DateTime, string>(
                LogLevel.Warning,
                eventId: new EventId(id: 42, name: "ERROR"),
                formatString: "{message} at {time}: {error}");


        //https://khalidabuhakmeh.com/handling-aspnet-core-exceptions-with-exceptionhandler-middleware
        public void OnGet()
        {

            // Grab the error message from the exception handler.
            var ctx = HttpContext;
            var exceptionPathFeature = ctx.Features.Get<IExceptionHandlerPathFeature>();

            if (ctx.Response.StatusCode == 404)
            {
                ErrorMessage = "The requested page could not be found.";
                ViewData["Message"] = "The requested page could not be found.";
                _logger.LogWarning($"404 Error - URL: {ctx.Request.GetDisplayUrl} {ctx.Response.StatusCode}");
            }
            else
            {
                ErrorMessage = exceptionPathFeature?.Error.Message ?? String.Empty;
                ViewData["Message"] = $"An error occurred with status code: {ctx.Response.StatusCode}";
                _logger.LogError($"Error {ctx.Response.StatusCode} - URL: {ctx.Request.Path}");
            }


            string message = $"Error page visited at {DateTime.Now}: {ErrorMessage}";
            _logger.LogWarning(message);

            // High performance logging using a delegate -- more efficient than calling the log* methods if the class
            // invokes logging in multiple methods because the log message needs to be parsed separately each time.
            // https://learn.microsoft.com/en-us/dotnet/core/extensions/high-performance-logging?view=aspnetcore-7.0
            _loggerMessage(this._logger, "Error page visited", DateTime.Now, ErrorMessage, null);
        }


    }
}