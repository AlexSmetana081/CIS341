/*
    Author: Alex Smetana
    CIS341
    09/28/2023
*/


using CIS341_lab3.Entity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Routing;
using System.Diagnostics;

namespace CIS341_lab3.Pages.About
{
    // Bind POST requests
    [BindProperties]


    public class ThanksModel : PageModel
    {

        public string CurrentDateTime { get; private set; }
        private LinkGenerator _linkgen;

        private const string DateTimeFormat = "yyyy-MM-dd HH:mm:ss";
        private const string ContactPagePath = "/About/Contact";



        public ThanksModel(LinkGenerator linkgen)
        {
            // Grab LinkGenerator object through DI.
            _linkgen = linkgen;
        }


        public void OnGet(string page)
        {
            CurrentDateTime = DateTime.Now.ToString(DateTimeFormat);
        }


        public IActionResult OnPost()
        {
            // Handle form submission logic here
            return Redirect(_linkgen.GetPathByPage(ContactPagePath));
        }
    }
}
