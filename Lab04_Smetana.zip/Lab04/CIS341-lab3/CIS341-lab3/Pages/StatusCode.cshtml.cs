using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CIS341_lab3.Pages
{
    public class StatusCodeModel : PageModel
    {

        private readonly ILogger<StatusCodeModel> _logger;

        public StatusCodeModel(ILogger<StatusCodeModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
            var statusCode = HttpContext.Request.Query["statusCode"];

            if (statusCode == "404")
            {
                ViewData["Message"] = "The requested page could not be found.";
                _logger.LogWarning($"404 Error - URL: {HttpContext.Request.Path}");
            }
            else
            {
                ViewData["Message"] = $"An error occurred with status code: {statusCode}";
                _logger.LogError($"Error {statusCode} - URL: {HttpContext.Request.Path}");
            }
        }

     
    }
}
