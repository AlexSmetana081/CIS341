﻿namespace Lab05.Models
{
    public class MessageModel
    {
        public int MessageId { get; set; }


        public int RecipientId { get; set; }
        public AccountModel Recipient { get; set; } = new AccountModel();

        public int SenderId { get; set; }
        public AccountModel Sender { get; set; } = new AccountModel();

        public string Content { get; set; } = string.Empty;
    }
}
