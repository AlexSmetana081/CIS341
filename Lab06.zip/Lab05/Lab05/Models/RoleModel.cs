﻿namespace Lab05.Models
{
    public class RoleModel
    {
        public int RoleId { get; set; } 
        public string Name { get; set; } = string.Empty;

    }
}
