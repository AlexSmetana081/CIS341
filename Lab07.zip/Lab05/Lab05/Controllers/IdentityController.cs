﻿using Lab05.Data;
using Lab05.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Lab05.Models;
using Microsoft.EntityFrameworkCore;

namespace Lab05.Controllers
{
    public class IdentityController : Controller
    {
        private readonly WorkoutContext _context;
        public IdentityController(WorkoutContext context)
        {
            _context = context;
        }

        // GET: IdentityController
        public ActionResult Index()
        {
            var models = _context.Role.ToList();
            return View(models);
        }

        // GET: IdentityController/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Role == null)
            {
                return NotFound();
            }

            var condition = await _context.Role
                .FirstOrDefaultAsync(m => m.RoleId == id);
            if (condition == null)
            {
                return NotFound();
            }

            return View(condition);
        }

        // GET: IdentityController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: IdentityController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("RoleId,Name")] RoleDTO role)
        {
            if (ModelState.IsValid)
            {
                Role r = new()
                {
                    RoleId = role.RoleId,
                    Name = role.Name,
                };
                _context.Add(r);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(role);
        }





        // GET: IdentityController/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Role == null)
            {
                return NotFound();
            }

            var condition = await _context.Role.FindAsync(id);
            if (condition == null)
            {
                return NotFound();
            }
            return View(condition);
        }

        // POST: IdentityController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("RoleId,Name")] Role role)
        {
            if (id != role.RoleId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(role);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RoleExists(role.RoleId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(role);
        }

        // GET: IdentityController/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Role == null)
            {
                return NotFound();
            }

            var condition = await _context.Role
                .FirstOrDefaultAsync(m => m.RoleId == id);
            if (condition == null)
            {
                return NotFound();
            }

            return View(condition);
        }

        // POST: IdentityController/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Role == null)
            {
                return Problem("Entity set 'CommunityStoreContext.Conditions'  is null.");
            }
            var condition = await _context.Role.FindAsync(id);
            if (condition != null)
            {
                _context.Role.Remove(condition);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public ActionResult Login()
        {
            return View();
        }

        private bool RoleExists(int id)
        {
            return _context.Role.Any(e => e.RoleId == id);
        }
    }
}
