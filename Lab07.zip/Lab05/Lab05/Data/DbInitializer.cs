﻿using Lab05.Models;
using Lab05.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace Lab05.Data
{
    public static class DbInitializer
    {
        public static void Initialize(WorkoutContext context)
        {
            context.Database.EnsureDeleted();

            context.Database.EnsureCreated();

            if (context.Account.Any())
            {
                return;
            }

            var role = new Role
            {
                //RoleId = 1,
                Name = "name1",
                Accounts = new List<Account>()
                 {
                      new Account ()
                      {
                           Name = "Name1",
                           Email = "exampleemail1@gmail.com",
                           Password= "password",
                      }
                 }
            };

            // Add Role to DbSet
            context.Role.Add(role);

            context.SaveChanges();


            var account = new Account()
            {
                //AccountId = 1,
                Name = "Name1",
                Email = "exampleemail1@gmail.com",
                Password = "password",
                Role = context.Role.First()
            };

            var account2 = new Account()
            {
                //AccountId = 1,
                Name = "Name2",
                Email = "exampleemail1@gmail.com",
                Password = "password",
                Role = context.Role.First()
            };

            // Add Accounts to DbSet
            context.Account.Add(account);
            context.Account.Add(account2);
            context.SaveChanges();

            var exercise = new Exercise()
            {
                //ExerciseId = 1,
                Name = "Name1",
                Description = "Description1",
                Length = 1,
                Intensity = 1,
                Account = context.Account.First(),
                  
            };

            // Add Role to DbSet
            context.Exercise.Add(exercise);

            context.SaveChanges();


            var workout = new Workout()
            {
                //WorkoutId = 1,
                Name = "name1",
                //AuthorId = 1,
                Author = context.Account.First(),
                Exercises = new List<Exercise>()
                {
                    context.Exercise.First()
                }
            };

            //Add Workout to DbSet
            context.Workouts.Add(workout);

            context.SaveChanges();

            var message = new Message()
            {
                Content = "1",
                Recipient = context.Account.First(),
                //Sender = context.Account.Skip(1).First(),
            };

            // Add Message to DbSet
            context.Message.Add(message);

            context.SaveChanges();

            var TrackedWorkoutModel = new TrackedWorkout()
            {
                DateCompleted = DateTime.Now,
                //Account = context.Account.Skip(1).First(),
                Workout = context.Workouts.First(),
            };

            ////Add Tracked Workout to Dbset
            context.TrackedWorkouts.Add(TrackedWorkoutModel);

            context.SaveChanges();
        }
    }
}
