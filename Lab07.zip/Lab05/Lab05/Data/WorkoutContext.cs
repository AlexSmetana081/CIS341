﻿using Lab05.Models;
using Microsoft.EntityFrameworkCore;
using System.Reflection;

namespace Lab05.Data
{
    public class WorkoutContext : DbContext
    {
        public WorkoutContext(DbContextOptions<WorkoutContext> options) : base(options) { }
        
        public DbSet<Account> Account { get; set; }
        public DbSet<Exercise> Exercise { get; set; }
        public DbSet<Message> Message { get; set; }
        public DbSet<Role> Role { get; set; }
        public DbSet<TrackedWorkout> TrackedWorkouts { get; set; }
        public DbSet<Workout> Workouts { get; set; }
        
    }
    
}

