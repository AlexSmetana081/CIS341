using Lab05.Data;
using Lab05.Models;
using Lab05.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;

namespace Lab05.Pages
{
    // Bind all public properties of the page model to request data for POST requests.
    [BindProperties]
    public class MakeWorkout2 : PageModel
    {
        private readonly WorkoutContext _context;
        public List<SelectListItem> Options { get; set; }
        public int? authorId { get; set; }

        public string? Message { get; set; }
        public const string? Placeholder = "Enter your message here.";

        public AccountDTO Account { get; set; } = new AccountDTO();

        //public List<int> Exercises { get; set; } = new List<int>();
        public List<Exercise> Exercises { get; set; } = new List<Exercise>();

        public List<WorkoutDTO> Workouts { get; set; } = new List<WorkoutDTO>();

        public List<WorkoutSetDTO> Sets { get; set; } = new List<WorkoutSetDTO>();

        //For dropdowns
        public List<SelectListItem> ExerciseList { get; set; } = new List<SelectListItem>();

        //private MakeWorkoutDTO _MakeWorkoutDTO = new MakeWorkoutDTO();
        public MakeWorkout2(WorkoutContext context)
        {
            _context = context;
        }
        public void OnGet()
        {
            var exercises = _context.Exercises.ToList();
            var exerciseList = new List<SelectListItem>();

            foreach (Exercise s in exercises)
            {
                exerciseList.Add(new SelectListItem { Value = s.ExerciseId.ToString(), Text = s.Name });
            }

            // Add list to ViewBag as a dynamic property.
            ExerciseList = exerciseList;
            Exercises = exercises;


            Options = exerciseList.Select(a => a).ToList();
            Options.First().Selected = true;
            // Shows the page
        }

        public IActionResult OnPost()
        {
            // Output to the debug console.
            // The public properties in the class are automatically bound from the form data.
            // Does not check whether the submitted data is valid; that's a story for another day.
            Debug.WriteLine($"Message is: {Message}");
            return new EmptyResult();
        }
    }
}
