﻿namespace Lab05.Models
{
    public enum Intensity
    {
        Low = 0, Medium = 1, High = 2
    }
}
