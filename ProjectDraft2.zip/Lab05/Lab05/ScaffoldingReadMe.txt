﻿Hello and Welcome to Workout App!

1. After downloading the app, it is important to update the authentication database. Enter the following command into the prompt:
	Update-Database -Context "WorkoutAuthenticationContext"

2. Next its time to login into the app. The 3 roles are Subscriber, Trainer, and Admin. You can create your own account or select from a premade account below. (Don't forget the period in the password)

Roles:

Subscriber:
	Username: subscriber@gmail.info
	Password: M0kkul4999.


Trainer:
	Username: trainer@gmail.info
	Password M0kkul4999.

Admin
	Username:admin@gmail.info
	Password: M0kkul4999.

3. Congrats your in. Have fun!